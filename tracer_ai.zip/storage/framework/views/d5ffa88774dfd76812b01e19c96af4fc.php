<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        PORTAL INFORMASI ALUMNI - LOWONGAN KERJA
    </title>

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>

    <?php echo app('Illuminate\Foundation\Vite')([
    'resources/css/user-dashboard.css',
    'resources/css/lowonganuser.css',
    'resources/js/app.jsx'
    ]); ?>

</head>


<body>

    <div id="root"></div>

</body>

</html><?php /**PATH C:\Laravel\tracer-ai-backend\resources\views/alumni/alumnilowongan.blade.php ENDPATH**/ ?>