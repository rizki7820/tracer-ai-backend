<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        PORTAL INFORMASI ALUMNI - BEASISWA
    </title>

    @viteReactRefresh

    @vite([
    'resources/css/user-dashboard.css',
    'resources/css/scholarshipuser.css',
    'resources/js/app.jsx'
    ])

</head>


<body>

    <div id="root"></div>

</body>

</html>